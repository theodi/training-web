<?php

	error_reporting(E_ALL^E_NOTICE);

	$handle1 = fopen('corruption.csv','r');
	$handle2 = fopen('score.csv','r');

	$corruption_headers = fgetcsv($handle1);
	print_r($corruption_headers);	

	while ($value = fgetcsv($handle1)) {
		$year = substr($value[2],0,4);
		$country = strtolower(trim($value[0]));
		if (strpos($country,",") > 0) {
			$country = substr($country,0,strpos($country,","));
		}
		$transaction = $value[1];		
		$data[$country][$year]["contribution"] += $transaction;
	}

	fclose($handle1);

	$year = 0;
	$country = "";

	$score_headers = fgetcsv($handle2);
	print_r($score_headers);
	
	while ($value = fgetcsv($handle2)) {
		$country = strtolower(trim($value[1]));
		if (strpos($country,",") > 0) {
			$country = substr($country,0,strpos($country,","));
		}
		$year = $value[3];
		$score = $value[2];
		$data[$country][$year]["CPI Score"] = $score;
	}
	
	fclose($handle2);

	foreach($data as $country => $values) {
		$cpi_count = 0;
		$contribution_count = 0;
		foreach($values as $year => $scores) {
			if ($scores["contribution"] > 0) {
				$contribution_count++;
			}
			if ($scores["CPI Score"] > 0) {
				$cpi_count++;
			}
		}
		if ($contribution_count == 0 | $cpi_count == 0) {
			if ($contribution_count == 0) {
				echo "No Contribution Data for $country\n";
			}
			if ($cpi_count == 0) {
				echo "No CPI Score data for $country\n";
			}
		} else {
			$final[$country] = $values;
		}
	}

	$handle5 = fopen("population.csv","r");	
	while ($value = fgetcsv($handle5)) {
		$country = strtolower(trim($value[0]));
		if (strpos($country,",") > 0) {
			$country = substr($country,0,strpos($country,","));
		}
		if ($final[$country]) {
			$final[$country][2010]["Population"] = $value[1];
			$final[$country][2011]["Population"] = $value[2];
			$final[$country][2012]["Population"] = $value[3];
			$final[$country][2013]["Population"] = $value[3] + (($value[3] - $value[1]) / 2);
		}
	}

	$foo["Asia"] = "Asia";
	$foo["Oceania"] = "Asia";
	$foo["Africa"] = "Africa";
	$foo["Europe"] = "Europe";
	$foo["Americas"] = "Americas";

	$handle4 = fopen("gapminderCountryColors.txt","r");
	$headings = fgets($handle4);
	while ($line = fgets($handle4)) {
		$parts = explode("|",$line);
		$country = strtolower(trim($parts[1]));
		$continent = trim($parts[0]);
		$colors[$country] = $foo[$continent];
	}
	fclose($handle4);

	$handle3 = fopen("out.csv","w");
	$out[] = "Country";
	$out[] = "Year";
	$out[] = "Contribution";
	$out[] = "CPI Score";
	$out[] = "Population";
	$out[] = "Color";
	fputcsv($handle3,$out);

	foreach($final as $country => $values) {
		foreach ($values as $year => $scores) {
			$out = [];
			$out[] = $country;
			$out[] = $year;
			$out[] = $scores["contribution"];
			$out[] = $scores["CPI Score"];
			$out[] = $scores["Population"];
			$out[] = $colors[$country];
			fputcsv($handle3,$out);
		}
	}
	fclose($handle3);
?>
