class Trader
  attr_reader :record_type, :name, :address, :comcode_count, :comcodes

  def initialize(line)
    @record_type = line[0,2]
    @name = line[2,104].strip
    @address = {
      :address1  => line[107,30].strip,
      :address2  => line[137,30].strip,
      :address3  => line[167,30].strip,
      :address4  => line[197,30].strip,
      :address5  => line[227,30].strip,
      :postcode  => line[257,7].strip
    }
    comcodes_raw = line[268,4234].strip
    @comcodes = comcodes_raw.split("|").select {|c| !c.empty?}
  end

  def to_a
    [record_type,name,address[:address1],address[:address2],address[:address3],address[:address4],address[:address5],address[:postcode],comcodes.length,comcodes.join("|")]
  end
end

