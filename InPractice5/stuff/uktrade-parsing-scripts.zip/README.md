# Import / Export data parsing scripts

`comcodes-to-csv.rb` and `traders-tocsv.rb` are Ruby scripts. They will respectively take a comcodes file or traders file, as downloaded from the uktradeinfo website, and print them out to STDOUT as CSV. They can then be piped into other script or dumped to disk.

Tested on Ruby 1.9.3.