require 'date'
class Comcode
  attr_reader :comcode,:intra_extra,:intra_date_on,:intra_date_off,:extra_date_on,:extra_date_off,:non_trade_id,:sitc_no,:sitc_ind,:sitc_conv_a,:sitc_conv_b,:cn_q2,:supplier_arrivals,:supplier_despatches,:supplier_imports,:supplier_exports,:sub_group_arr,:item_arr,:sub_group_desp,:item_desp,:sub_group_imp,:item_imp,:sub_group_exp,:item_exp,:qty1,:qty2,:commodity1,:commodity2

  def initialize(line)
    data = line.split("|")
    @comcode = data[0]
    @intra_extra = data[1]

    intra_date_on_fragments = data[2].split("/").map {|i| i.to_i}
    if intra_date_on_fragments.uniq != [0]
      @intra_date_on = Date.new(2000+intra_date_on_fragments[1], intra_date_on_fragments[0],1)
    else
      @intra_date_on = nil
    end

    intra_date_off_fragments = data[3].split("/").map {|i| i.to_i}
    if intra_date_off_fragments.uniq != [0]
      @intra_date_off = Date.new(2000+intra_date_off_fragments[1], intra_date_off_fragments[0],1)
    else
      @intra_date_off = nil
    end

    extra_date_on_fragments = data[4].split("/").map {|i| i.to_i}
    if extra_date_on_fragments.uniq != [0]
      @extra_date_on = Date.new(2000+extra_date_on_fragments[1],extra_date_on_fragments[0],1)
    else
      @extra_date_on = nil
    end

    extra_date_off_fragments = data[5].split("/").map {|i| i.to_i}
    if extra_date_off_fragments.uniq != [0]
      @extra_date_off = Date.new(2000+extra_date_off_fragments[1], extra_date_off_fragments[0], 1)
    else
      @extra_date_off = nil
    end

    @non_trade_id = data[6]
    @sitc_no = data[7]
    @sitc_ind = data[8]
    @sitc_conv_a = data[9]
    @sitc_conv_b = data[10]
    @cn_q2 = data[11]
    @supplier_arrivals = data[12]
    @supplier_despatches = data[13]
    @supplier_imports = data[14]
    @supplier_exports = data[15]
    @sub_group_arr = data[16]
    @item_arr = data[17]
    @sub_group_desp = data[18]
    @item_desp = data[19]
    @sub_group_imp = data[20]
    @item_imp = data[21]
    @sub_group_exp = data[22]
    @item_exp = data[23]
    @qty1 = data[24]
    @qty2 = data[25]
    @commodity1 = data[26]
    @commodity2 = data[27]
  end

  def to_a
    [comcode,intra_extra,intra_date_on,intra_date_off,extra_date_on,extra_date_off,non_trade_id,sitc_no,sitc_ind,sitc_conv_a,sitc_conv_b,cn_q2,supplier_arrivals,supplier_despatches,supplier_imports,supplier_exports,sub_group_arr,item_arr,sub_group_desp,item_desp,sub_group_imp,item_imp,sub_group_exp,item_exp,qty1,qty2,commodity1,commodity2]
  end
end
