require 'csv'


unless ARGV[0]
  puts "Usage: traders-to-csv.rb [traderfile]"
  exit
end

rawlines = File.readlines(ARGV[0])

traders = []

rawlines.each do |line|
  if line.length > 278
    traders << Trader.new(line)
  else
    next
  end
end

csv_string = CSV.generate do |row|
  row << %w{record_type name address1 address2 address3 address4 address5 postcode comcode_count comcodes}
  traders.each do |trader|
    row << trader.to_a
  end
end

puts csv_string
