require 'csv'
require './comcode.rb'

unless ARGV[0]
  puts "Usage: comcodes-tocsv.rb [comcodefile]"
  exit
end

file = File.read(ARGV[0], :encoding => 'iso-8859-1')

rawlines = file.split("\n")

comcodes = []

lines = rawlines.map do |l| 
  comcodes << Comcode.new(l.strip)
end

csv_string = CSV.generate do |row|
  row << %w{comcode,intra_extra,intra_date_on,intra_date_off,extra_date_on,extra_date_off,non_trade_id,sitc_no,sitc_ind,sitc_conv_a,sitc_conv_b,cn_q2,supplier_arrivals,supplier_despatches,supplier_imports,supplier_exports,sub_group_arr,item_arr,sub_group_desp,item_desp,sub_group_imp,item_imp,sub_group_exp,item_exp,qty1,qty2,commodity1,commodity2}
  comcodes.each do |comcode|
    row << comcode.to_a
  end
end

puts csv_string
